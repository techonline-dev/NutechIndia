import React, {Component} from 'react';
import NavBar from '../components/NavBar';
import Footer from '../components/Footer';
import MobileMenu from '../components/MobileMenu';
import { FacebookLoginButton } from "react-social-login-buttons";
import { GoogleLoginButton } from "react-social-login-buttons";


class Signup extends Component{
    render(){
        return(
            <div>
                {/* Navigation bar */}
                <NavBar/>

                {/* breadcrumb */}
                {/*====================  breadcrumb area ====================*/}
                <div className="breadcrumb-area breadcrumb-bg">
                    <div className="container">
                        <div className="row">
                            <div className="col">
                                <div className="page-banner">
                                    <h1>LOGIN / REGISTER</h1>
                                    <ul className="page-breadcrumb">
                                        <li><a href="/">Home</a></li>
                                        <li>LOGIN / REGISTER</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/*====================  End of breadcrumb area  ====================*/}

                {/*====================  content page content ====================*/}
                <div className="page-wrapper section-space--inner--60">
                {/*Contact section start*/}
                <div className="conact-section">
                    <div className="container">
                   
                    <div className="row">
                        <div className="col-lg-6 col-12 contact">
                            <h3 class="section-title mb-0">REGISTER</h3>
                        <div className="contact-form">
                            <form id="contact-form">
                            <div className="row row-10">
                                <div className="col-md-6 col-12 section-space--bottom--20"><input name="con_Fname" type="text" placeholder="First Name" /></div>
                                <div className="col-md-6 col-12 section-space--bottom--20"><input name="con_Lname" type="text" placeholder="Last Name" /></div>
                                <div className="col-md-12 col-12 section-space--bottom--20"><input name="con_email" type="email" placeholder="email@example.com" /></div>
                                <div className="col-md-12 col-12 section-space--bottom--20"><input name="Mobile No" type="Number" placeholder="Your Mobile Number" /></div>
                                <div className="col-md-6 col-12 section-space--bottom--20"><input name="con_Password" type="password" placeholder="Password" /></div>
                                <div className="col-md-6 col-12 section-space--bottom--20"><input name="con_Lname" type="password" placeholder="Confirm Password" /></div>
                                <div className="col-12"><button>Register</button></div>
                            </div>
                            </form>
                        </div>
                       
                        </div>
                        <div className="col-lg-2 col-12">
</div>
 <div className="col-lg-4 col-12 contact section-space--100">
                        <h3 class="section-title mb-0">LOGIN </h3>
                        <div className="contact-form">
                            <form id="contact-form">
                            <div className="row row-10">
                                <div className="col-md-12 col-12 section-space--bottom--20"><input name="con_email" type="email" placeholder="email@example.com" /></div>
                                <div className="col-md-12 col-12 section-space--bottom--20"><input name="con_Password" type="password" placeholder="Password" /></div>
                                <div className="col-12"><button>Login</button></div>
                                <FacebookLoginButton onClick={() => alert("Hello")} />
                                <GoogleLoginButton onClick={() => alert("Hello")} />

                            </div>
                            </form>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                {/*Contact section end*/}
                </div>
                {/*====================  End of content page content  ====================*/}
                
                {/* Footer */}
                <Footer/>

                {/* Mobile Menu */}
                <MobileMenu/>

            </div>
        )
    }
}


export default Signup;
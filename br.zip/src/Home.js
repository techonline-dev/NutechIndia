import React, {Component} from 'react';
import NavBar from './components/NavBar';
import Slider from './components/Slider';
import VideoCta from './components/VideoCta';
import ProjectSliderTwo from './components/ProjectSliderTwo';
import ServiceTab from './components/ServiceTab';
import TestimonialSlider from './components/TestimonialSlider';
import BrandLogoSlider from './components/BrandLogoSlider';
import TeamJob from './components/TeamJob';
import Footer from './components/Footer';
import MobileMenu from './components/MobileMenu';


class Home extends Component{
    render(){
        
        return(
            <div>
                
                {/* Navigation bar */}
                <NavBar/>
                
                {/* Hero slider */}
                <Slider/>
                
                {/* Video CTA */}
                <VideoCta/>
                
                {/* Project Slider */}
                <ProjectSliderTwo/>
                
                {/* Service Tab */}
                <ServiceTab/>
                
                {/* Testimonial Slider */}
                <TestimonialSlider/>
                
                {/* Team job */}
                <TeamJob/>

                  {/* Team job */}
                  <BrandLogoSlider />

                {/* Footer */}
                <Footer/>

                {/* Mobile Menu */}
                <MobileMenu/>

            </div>
        )
    }
}


export default Home;